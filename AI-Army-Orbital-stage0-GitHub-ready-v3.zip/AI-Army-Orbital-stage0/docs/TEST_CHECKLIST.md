# Stage 0 in-game acceptance checklist

- [ ] Both modules compile against the exact Minecraft 26.2 platform APIs.
- [ ] Paper plugin loads without startup errors.
- [ ] Fabric mod loads without startup errors.
- [ ] Non-OP cannot grant wands; OP can grant all six.
- [ ] Renaming a wand to anything except the exact expected name disables it.
- [ ] First right-click arms; second confirms; hotbar switch cancels.
- [ ] Successful use consumes exactly one wand, including with Mending.
- [ ] Nuke spawns exactly 661 TNT entities (660 ring + 1 center).
- [ ] TNT detonates near the target surface and coverage gaps are measured in a flat test world.
- [ ] Stab remains a narrow column and opens a path toward bedrock.
- [ ] Strike fires ten waves of 100 charged Wither skulls; test water and obsidian interactions.
- [ ] Wolf spawns 50 owned wolves with Strength II, Speed II and Wolf Armor.
- [ ] Boss spawns exactly 100 of the configured type and performance is measured.
- [ ] Stasis refuses invalid/unsafe destinations and teleports to a safe destination.
- [ ] Nuke limit is 3 per army/team per five minutes; Strike limit is 1 per army/team per five minutes.
- [ ] Stab, Wolf, Boss and Stasis cooldowns are 25 seconds.
- [ ] Restart behavior and persistence are checked.
