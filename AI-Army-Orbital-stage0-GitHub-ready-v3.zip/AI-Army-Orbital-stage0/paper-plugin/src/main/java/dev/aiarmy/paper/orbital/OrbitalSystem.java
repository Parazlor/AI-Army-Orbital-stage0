package dev.aiarmy.paper.orbital;

import dev.aiarmy.paper.AIArmyOrbitalPlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.Warden;
import org.bukkit.entity.Wither;
import org.bukkit.entity.WitherSkull;
import org.bukkit.entity.Wolf;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.Team;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.UUID;

/** Orbital System stage 0. Kept independent so later AI Army stages can supply a real army id. */
public final class OrbitalSystem implements Listener {
    private static final long ARM_WINDOW_MS = 10_000L;
    private static final long FIVE_MINUTES_MS = 300_000L;
    private static final long PERSONAL_COOLDOWN_MS = 25_000L;
    private static final int STRIKE_WAVES = 10;
    private static final int STRIKE_PER_WAVE = 100;

    private final AIArmyOrbitalPlugin plugin;
    private final Map<UUID, PendingUse> pending = new HashMap<>();
    private final Map<UUID, Long> personalCooldowns = new HashMap<>();
    private final Map<UUID, String> bossModes = new HashMap<>();
    private final Map<UUID, Location> stasisTargets = new HashMap<>();
    private final Map<String, Queue<Long>> nukeUses = new HashMap<>();
    private final Map<String, Queue<Long>> strikeUses = new HashMap<>();

    public OrbitalSystem(AIArmyOrbitalPlugin plugin) {
        this.plugin = plugin;
        loadStasisTargets();
    }

    public void shutdown() {
        pending.clear();
    }

    public ItemStack createWand(WandType type) {
        ItemStack item = new ItemStack(Material.BLAZE_ROD);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(type.label());
            meta.setLore(java.util.List.of("AI Army Orbital", "Right-click to arm; right-click again to confirm", "Switching hotbar slot cancels"));
            item.setItemMeta(meta);
        }
        return item;
    }

    public void setBossMode(Player player, String mode) {
        bossModes.put(player.getUniqueId(), mode.equalsIgnoreCase("Wither") ? "WITHER" : "WARDEN");
    }

    public void setStasisDestination(Player player, double x, double y, double z) {
        Location loc = new Location(player.getWorld(), x, y, z);
        stasisTargets.put(player.getUniqueId(), loc);
        String path = "stasis." + player.getUniqueId();
        plugin.getConfig().set(path + ".world", player.getWorld().getName());
        plugin.getConfig().set(path + ".x", x);
        plugin.getConfig().set(path + ".y", y);
        plugin.getConfig().set(path + ".z", z);
        plugin.saveConfig();
    }

    private void loadStasisTargets() {
        if (!plugin.getConfig().isConfigurationSection("stasis")) return;
        for (String id : plugin.getConfig().getConfigurationSection("stasis").getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(id);
                String path = "stasis." + id;
                World world = Bukkit.getWorld(plugin.getConfig().getString(path + ".world", ""));
                if (world == null) continue;
                stasisTargets.put(uuid, new Location(world,
                        plugin.getConfig().getDouble(path + ".x"),
                        plugin.getConfig().getDouble(path + ".y"),
                        plugin.getConfig().getDouble(path + ".z")));
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Ignoring invalid Stasis UUID in config: " + id);
            }
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        WandType type = readExactWand(item);
        if (type == null) return;
        event.setCancelled(true);

        PendingUse previous = pending.get(player.getUniqueId());
        long now = System.currentTimeMillis();
        if (previous != null && previous.expiresAt >= now && previous.slot == player.getInventory().getHeldItemSlot() && previous.type == type) {
            pending.remove(player.getUniqueId());
            Location target = type == WandType.STASIS ? null : getTarget(player);
            if (type != WandType.STASIS && target == null) {
                player.sendMessage("§cAim at a block within 100 blocks, then confirm again.");
                return;
            }
            if (execute(player, type, target)) consumeHeldWand(player);
            return;
        }

        pending.put(player.getUniqueId(), new PendingUse(type, player.getInventory().getHeldItemSlot(), now + ARM_WINDOW_MS));
        player.sendMessage("§e" + type.label() + " armed. Right-click again within 10 seconds to confirm.");
        if (type == WandType.BOSS) player.sendMessage("§7Boss type: " + bossModes.getOrDefault(player.getUniqueId(), "WARDEN"));
    }

    @EventHandler
    public void onSlotChange(PlayerItemHeldEvent event) {
        if (pending.remove(event.getPlayer().getUniqueId()) != null) {
            event.getPlayer().sendMessage("§7Orbital operation cancelled: selected slot changed.");
        }
    }

    private Location getTarget(Player player) {
        Block block = player.getTargetBlockExact(100);
        return block == null ? null : block.getLocation().add(0.5, 1.0, 0.5);
    }

    private boolean execute(Player player, WandType type, Location target) {
        long now = System.currentTimeMillis();
        UUID id = player.getUniqueId();
        if (type == WandType.NUKE && !takeRateLimit(nukeUses, armyKey(player), 3, now)) {
            player.sendMessage("§cNuke limit reached: 3 uses per army/team every 5 minutes."); return false;
        }
        if (type == WandType.STRIKE && !takeRateLimit(strikeUses, armyKey(player), 1, now)) {
            player.sendMessage("§cStrike limit reached: 1 use per army/team every 5 minutes."); return false;
        }
        if (type != WandType.NUKE && type != WandType.STRIKE) {
            long readyAt = personalCooldowns.getOrDefault(id, 0L);
            if (readyAt > now) {
                player.sendMessage("§cCooldown: " + ((readyAt - now + 999) / 1000) + " seconds."); return false;
            }
        }

        try {
            switch (type) {
                case NUKE -> spawnNuke(target);
                case STAB -> spawnStab(target);
                case STRIKE -> spawnStrike(target);
                case WOLF -> spawnWolves(player);
                case BOSS -> spawnBosses(player, target);
                case STASIS -> {
                    Location destination = stasisTargets.get(id);
                    if (destination == null || destination.getWorld() == null) {
                        player.sendMessage("§cNo Stasis destination configured. Ask an OP to set /aiarmyorbital Stasis <x> <y> <z>."); return false;
                    }
                    Location safe = findSafeDestination(destination);
                    if (safe == null) {
                        player.sendMessage("§cStasis destination is not safe or is outside the world bounds."); return false;
                    }
                    if (!player.teleport(safe)) { player.sendMessage("§cTeleport failed."); return false; }
                }
            }
        } catch (RuntimeException ex) {
            plugin.getLogger().severe("Orbital " + type.label() + " failed: " + ex.getMessage());
            player.sendMessage("§cOrbital failed; wand was not consumed. Check server log.");
            return false;
        }

        if (type == WandType.NUKE || type == WandType.STRIKE) {
            // The rate-limit reservation was already taken. If the operation throws, it remains reserved
            // intentionally to prevent rapid repeated attempts from creating a server-load exploit.
        } else {
            personalCooldowns.put(id, now + PERSONAL_COOLDOWN_MS);
        }
        player.sendMessage("§a" + type.label() + " activated.");
        return true;
    }

    private void spawnNuke(Location target) {
        World world = target.getWorld();
        int[] counts = {40, 50, 60, 70, 80, 90, 110, 160}; // sum = 660
        double[] radii = {3.0, 5.5, 8.0, 11.0, 14.5, 18.5, 23.0, 28.0};
        spawnPrimedTnt(world, target.clone().add(0, 50, 0), 72);
        for (int ring = 0; ring < counts.length; ring++) {
            final int count = counts[ring];
            final double radius = radii[ring];
            for (int i = 0; i < count; i++) {
                double angle = (Math.PI * 2.0 * i / count) + (ring % 2 == 0 ? 0 : Math.PI / count);
                Location spawn = target.clone().add(Math.cos(angle) * radius, 50, Math.sin(angle) * radius);
                spawnPrimedTnt(world, spawn, 72);
            }
        }
    }

    private void spawnStab(Location target) {
        World world = target.getWorld();
        int minY = world.getMinHeight() + 1;
        int topY = Math.min(world.getMaxHeight() - 2, target.getBlockY() + 50);
        // One narrow column; each TNT has a staggered fuse to carry the strike down through the column.
        int index = 0;
        for (int y = topY; y >= minY; y -= 4) {
            Location loc = new Location(world, target.getBlockX() + 0.5, y, target.getBlockZ() + 0.5);
            spawnPrimedTnt(world, loc, Math.max(20, 80 + index / 2));
            index++;
        }
    }

    private void spawnStrike(Location target) {
        World world = target.getWorld();
        for (int wave = 0; wave < STRIKE_WAVES; wave++) {
            final int waveNo = wave;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!world.isChunkLoaded(target.getBlockX() >> 4, target.getBlockZ() >> 4)) return;
                for (int i = 0; i < STRIKE_PER_WAVE; i++) {
                    double angle = (Math.PI * 2.0 * i / STRIKE_PER_WAVE) + (waveNo * 0.37);
                    double radius = 24.0 + ((i % 5) * 2.0);
                    Location start = target.clone().add(Math.cos(angle) * radius, 10 + (i % 7), Math.sin(angle) * radius);
                    WitherSkull skull = world.spawn(start, WitherSkull.class);
                    skull.setCharged(true);
                    skull.setShooter(null);
                    org.bukkit.util.Vector direction = target.clone().subtract(start).toVector();
                    if (direction.lengthSquared() > 0.001) skull.setVelocity(direction.normalize().multiply(1.8));
                }
            }, wave * 12L);
        }
    }

    private void spawnWolves(Player activator) {
        Location center = activator.getLocation();
        World world = center.getWorld();
        for (int i = 0; i < 50; i++) {
            final int n = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                double angle = n * 2.399963229728653;
                double radius = 1.5 + Math.sqrt(n) * 0.8;
                Location at = center.clone().add(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
                Wolf wolf = world.spawn(at, Wolf.class);
                wolf.setTamed(true);
                wolf.setOwner(activator);
                wolf.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 20 * 60 * 10, 1, true, true));
                wolf.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 60 * 10, 1, true, true));
                ItemStack armor = new ItemStack(Material.WOLF_ARMOR);
                wolf.setBodyArmor(armor);
                wolf.setTarget(null);
            }, i / 5L);
        }
    }

    private void spawnBosses(Player activator, Location target) {
        World world = target.getWorld();
        String mode = bossModes.getOrDefault(activator.getUniqueId(), "WARDEN");
        // One in the centre and 99 in concentric rings. Staggered to reduce a single-tick spike.
        for (int i = 0; i < 100; i++) {
            final int n = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                Location at;
                if (n == 0) at = target.clone();
                else {
                    int ring = (int) Math.ceil(Math.sqrt(n));
                    double radius = 2.5 + ring * 2.5;
                    double angle = n * 2.399963229728653;
                    at = target.clone().add(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
                }
                if (mode.equals("WITHER")) world.spawn(at, Wither.class);
                else world.spawn(at, Warden.class);
            }, i / 5L);
        }
    }

    private void spawnPrimedTnt(World world, Location location, int fuseTicks) {
        TNTPrimed tnt = world.spawn(location, TNTPrimed.class);
        tnt.setFuseTicks(fuseTicks);
        tnt.setIsIncendiary(false);
        tnt.setYield(4.0f);
    }

    private Location findSafeDestination(Location requested) {
        World world = requested.getWorld();
        if (world == null || requested.getY() < world.getMinHeight() + 1 || requested.getY() >= world.getMaxHeight() - 2) return null;
        int x = requested.getBlockX(), z = requested.getBlockZ(), baseY = requested.getBlockY();
        for (int delta = 0; delta <= 8; delta++) {
            for (int sign : delta == 0 ? new int[]{1} : new int[]{1, -1}) {
                int y = baseY + delta * sign;
                if (y < world.getMinHeight() + 1 || y >= world.getMaxHeight() - 2) continue;
                Block floor = world.getBlockAt(x, y - 1, z);
                Block feet = world.getBlockAt(x, y, z);
                Block head = world.getBlockAt(x, y + 1, z);
                if (floor.getType().isSolid() && feet.isPassable() && head.isPassable() && !feet.isLiquid() && !head.isLiquid()) {
                    return new Location(world, x + 0.5, y, z + 0.5, requested.getYaw(), requested.getPitch());
                }
            }
        }
        return null;
    }

    private boolean takeRateLimit(Map<String, Queue<Long>> limits, String key, int maximum, long now) {
        Queue<Long> queue = limits.computeIfAbsent(key, ignored -> new ArrayDeque<>());
        while (!queue.isEmpty() && now - queue.peek() >= FIVE_MINUTES_MS) queue.poll();
        if (queue.size() >= maximum) return false;
        queue.add(now);
        return true;
    }

    private String armyKey(Player player) {
        Team team = Bukkit.getScoreboardManager().getMainScoreboard().getEntryTeam(player.getName());
        // Until the army subsystem exists, a scoreboard team is treated as an army; solo players are isolated.
        return team == null ? "player:" + player.getUniqueId() : "team:" + team.getName();
    }

    private void consumeHeldWand(Player player) {
        ItemStack item = player.getInventory().getItemInMainHand();
        if (readExactWand(item) == null) return;
        if (item.getAmount() <= 1) player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
        else item.setAmount(item.getAmount() - 1);
        player.updateInventory();
    }

    private WandType readExactWand(ItemStack item) {
        if (item == null || item.getType() != Material.BLAZE_ROD || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasDisplayName()) return null;
        String name = ChatColor.stripColor(meta.getDisplayName());
        return WandType.parse(name);
    }

    public enum WandType {
        NUKE("Nuke"), STAB("Stab"), STRIKE("Strike"), STASIS("Stasis"), WOLF("Wolf"), BOSS("Boss");
        private final String label;
        WandType(String label) { this.label = label; }
        public String label() { return label; }
        public static WandType parse(String input) {
            if (input == null) return null;
            for (WandType type : values()) if (type.label.equals(input.trim())) return type;
            return null;
        }
    }

    private record PendingUse(WandType type, int slot, long expiresAt) {}
}
