package dev.aiarmy.paper;

import dev.aiarmy.paper.orbital.OrbitalSystem;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Locale;

public final class AIArmyOrbitalPlugin extends JavaPlugin {
    private OrbitalSystem orbital;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        orbital = new OrbitalSystem(this);
        getServer().getPluginManager().registerEvents(orbital, this);
        getLogger().info("Orbital System enabled. This stage contains the orbital module only.");
    }

    @Override
    public void onDisable() {
        if (orbital != null) orbital.shutdown();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage("§6AI Army Orbital §7— §f/give <player> <Nuke|Stab|Strike|Stasis|Wolf|Boss>");
            sender.sendMessage("§7/aiarmyorbital Boss <Warden|Wither> — set your Boss wand type");
            sender.sendMessage("§7/aiarmyorbital Stasis <x> <y> <z> — set your Stasis destination in your current world");
            sender.sendMessage("§7Right-click a wand to arm it; right-click again to confirm. Changing hotbar slot cancels.");
            return true;
        }

        if (args[0].equalsIgnoreCase("give")) {
            if (!sender.hasPermission("aiarmy.orbital.admin")) {
                sender.sendMessage("§cOnly OPs can grant orbital wands.");
                return true;
            }
            if (args.length != 3) {
                sender.sendMessage("§cUsage: /aiarmyorbital give <player> <Nuke|Stab|Strike|Stasis|Wolf|Boss>");
                return true;
            }
            Player target = getServer().getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage("§cPlayer not online: " + args[1]);
                return true;
            }
            OrbitalSystem.WandType type = OrbitalSystem.WandType.parse(args[2]);
            if (type == null) {
                sender.sendMessage("§cUnknown wand. Choose Nuke, Stab, Strike, Stasis, Wolf or Boss.");
                return true;
            }
            target.getInventory().addItem(orbital.createWand(type));
            sender.sendMessage("§aGranted " + type.label() + " wand to " + target.getName() + ".");
            return true;
        }

        if (args[0].equalsIgnoreCase("Boss")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("§cThis command requires a player.");
                return true;
            }
            if (args.length != 2 || !(args[1].equalsIgnoreCase("Warden") || args[1].equalsIgnoreCase("Wither"))) {
                sender.sendMessage("§cUsage: /aiarmyorbital Boss <Warden|Wither>");
                return true;
            }
            orbital.setBossMode(player, args[1].toUpperCase(Locale.ROOT));
            player.sendMessage("§aBoss wand configured: " + args[1] + ". Hold your Boss wand to use it.");
            return true;
        }

        if (args[0].equalsIgnoreCase("Stasis")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("§cThis command requires a player so the destination world can be selected.");
                return true;
            }
            if (!player.hasPermission("aiarmy.orbital.admin")) {
                player.sendMessage("§cOnly OPs can configure Stasis coordinates.");
                return true;
            }
            if (args.length != 4) {
                player.sendMessage("§cUsage: /aiarmyorbital Stasis <x> <y> <z>");
                return true;
            }
            try {
                double x = Double.parseDouble(args[1]);
                double y = Double.parseDouble(args[2]);
                double z = Double.parseDouble(args[3]);
                orbital.setStasisDestination(player, x, y, z);
                player.sendMessage("§aStasis destination set in world " + player.getWorld().getName() + ".");
            } catch (NumberFormatException ex) {
                player.sendMessage("§cCoordinates must be numbers.");
            }
            return true;
        }

        sender.sendMessage("§cUnknown subcommand. Use /aiarmyorbital help");
        return true;
    }
}
