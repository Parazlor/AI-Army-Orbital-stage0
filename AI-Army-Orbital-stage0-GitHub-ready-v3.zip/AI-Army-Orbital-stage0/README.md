# AI Army — Orbital System, Stage 0

This is the first additive stage of the AI Army project. It contains separate implementations for:

- `paper-plugin/` — Paper server plugin
- `fabric-mod/` — Fabric mod for a singleplayer Fabric installation or Fabric server

The intended target is Minecraft 26.2 / Java 25, following AI Army Technical Specification v1.2.

## Included mechanics

- Exact-name Blaze Rod wands: `Nuke`, `Stab`, `Strike`, `Stasis`, `Wolf`, `Boss`.
- OP-only grant command: `/aiarmyorbital give <player> <wand>`.
- Two-click arming/confirmation with a 10-second window; changing the selected hotbar slot cancels on the Fabric implementation, and slot change cancels on Paper.
- Nuke ring distribution is 40 + 50 + 60 + 70 + 80 + 90 + 110 + 160 = 660 TNT, plus one central TNT (661 total).
- Strike defaults to ten waves of 100 charged Wither skulls.
- Wolf calls 50 wolves with Strength II, Speed II, ownership and Wolf Armor where supported by the platform API.
- Boss calls 100 Wardens or Withers; configure the mode with `/aiarmyorbital Boss <Warden|Wither>`.
- Stasis target command: `/aiarmyorbital Stasis <x> <y> <z>`; it uses the configuring player's current world.
- Successful activation consumes the wand. Exact display/custom name is required.
- Nuke/Strike rate limits and per-player cooldowns are included.

## Important stage-0 boundaries

The AI Army and army-identity subsystem does not exist yet. Until it is added, rate limits use a scoreboard team as a temporary army identity on Paper, and player identity on Fabric. This is deliberately documented and should be replaced with the shared Army ID in a later stage. Stasis settings persist in the Paper plugin config; the Fabric stage currently keeps its Stasis target in memory, so restart persistence remains a follow-up fix before calling the two platforms fully equivalent.

The exact TNT detonation height, full surface coverage, behavior against water/obsidian, the 100-boss performance impact, and the Minecraft 26.2 API compatibility must be validated in a real test world. The project is not marked as release-verified until it has been built against the target platform dependencies and tested in-game.

## Commands

- `/aiarmyorbital help`
- `/aiarmyorbital give <player> <Nuke|Stab|Strike|Stasis|Wolf|Boss>` — OP/admin permission
- `/aiarmyorbital Boss <Warden|Wither>` — sets the Boss wand type for the player issuing the command
- `/aiarmyorbital Stasis <x> <y> <z>` — sets Stasis destination in the current world (OP/admin permission)

## Build

Requires a Java 25 JDK and a working Gradle installation. Run `gradle buildAll` from this directory. The build needs network access to the Paper, Fabric and Minecraft dependency repositories. The current ChatGPT execution environment did not have Gradle installed or network access to fetch a Gradle distribution, so these JARs have not been built or runtime-tested here.
