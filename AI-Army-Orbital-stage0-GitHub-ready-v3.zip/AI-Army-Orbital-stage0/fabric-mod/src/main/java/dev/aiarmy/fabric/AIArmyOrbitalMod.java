package dev.aiarmy.fabric;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.mob.WardenEntity;
import net.minecraft.entity.projectile.WitherSkullEntity;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.UUID;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/** Fabric implementation of Orbital System stage 0. */
public final class AIArmyOrbitalMod implements ModInitializer {
    private static final long ARM_MS = 10_000L;
    private static final long FIVE_MIN_MS = 300_000L;
    private static final Map<UUID, Pending> PENDING = new HashMap<>();
    private static final Map<UUID, Long> COOLDOWNS = new HashMap<>();
    private static final Map<UUID, String> BOSS_MODE = new HashMap<>();
    private static final Map<UUID, StasisTarget> STASIS = new HashMap<>();
    private static final Map<String, Queue<Long>> NUKE_USES = new HashMap<>();
    private static final Map<String, Queue<Long>> STRIKE_USES = new HashMap<>();

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(literal("aiarmyorbital")
                .then(literal("give").requires(src -> src.hasPermissionLevel(2))
                    .then(argument("player", StringArgumentType.word())
                    .then(argument("wand", StringArgumentType.word()).executes(ctx -> {
                        ServerCommandSource src = ctx.getSource();
                        ServerPlayerEntity target = src.getServer().getPlayerManager().getPlayer(StringArgumentType.getString(ctx, "player"));
                        Wand type = Wand.parse(StringArgumentType.getString(ctx, "wand"));
                        if (target == null || type == null) { src.sendError(Text.literal("Usage: /aiarmyorbital give <player> <Nuke|Stab|Strike|Stasis|Wolf|Boss>")); return 0; }
                        target.getInventory().insertStack(makeWand(type));
                        src.sendFeedback(() -> Text.literal("Granted " + type.label + " to " + target.getName().getString()), false);
                        return 1;
                    }))))
                .then(literal("Boss").then(argument("type", StringArgumentType.word()).executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                    String mode = StringArgumentType.getString(ctx, "type");
                    if (!mode.equalsIgnoreCase("Warden") && !mode.equalsIgnoreCase("Wither")) { ctx.getSource().sendError(Text.literal("Use Warden or Wither.")); return 0; }
                    BOSS_MODE.put(player.getUuid(), mode.equalsIgnoreCase("Wither") ? "WITHER" : "WARDEN");
                    player.sendMessage(Text.literal("Boss wand configured: " + mode), false);
                    return 1;
                })))
                .then(literal("Stasis").requires(src -> src.hasPermissionLevel(2))
                    .then(argument("x", DoubleArgumentType.doubleArg())
                    .then(argument("y", DoubleArgumentType.doubleArg())
                    .then(argument("z", DoubleArgumentType.doubleArg()).executes(ctx -> {
                        ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                        STASIS.put(player.getUuid(), new StasisTarget(player.getServerWorld().getRegistryKey().getValue().toString(),
                            DoubleArgumentType.getDouble(ctx, "x"), DoubleArgumentType.getDouble(ctx, "y"), DoubleArgumentType.getDouble(ctx, "z")));
                        player.sendMessage(Text.literal("Stasis destination configured in current world."), false);
                        return 1;
                    })))))
                .then(literal("help").executes(ctx -> {
                    ctx.getSource().sendFeedback(() -> Text.literal("/aiarmyorbital give <player> <wand> | Boss <Warden|Wither> | Stasis <x> <y> <z>"), false);
                    return 1;
                })));
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> PENDING.entrySet().removeIf(entry -> {
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(entry.getKey());
            return player == null || player.getInventory().selectedSlot != entry.getValue().slot || entry.getValue().expiresAt < System.currentTimeMillis();
        }));

        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.isClient || hand != Hand.MAIN_HAND || !(player instanceof ServerPlayerEntity serverPlayer)) return TypedActionResult.pass(player.getStackInHand(hand));
            ItemStack stack = serverPlayer.getStackInHand(hand);
            Wand type = readWand(stack);
            if (type == null) return TypedActionResult.pass(player.getStackInHand(hand));
            long now = System.currentTimeMillis();
            Pending old = PENDING.get(serverPlayer.getUuid());
            int selectedSlot = serverPlayer.getInventory().selectedSlot;
            if (old == null || old.type != type || old.slot != selectedSlot || old.expiresAt < now) {
                PENDING.put(serverPlayer.getUuid(), new Pending(type, selectedSlot, now + ARM_MS));
                serverPlayer.sendMessage(Text.literal(type.label + " armed. Use the same wand again within 10 seconds to confirm."), true);
                return TypedActionResult.fail(stack);
            }
            PENDING.remove(serverPlayer.getUuid());
            if (type == Wand.STASIS) {
                if (!useStasis(serverPlayer)) return TypedActionResult.fail(stack);
            } else {
                HitResult hit = serverPlayer.raycast(100.0, 1.0F, false);
                if (!(hit instanceof BlockHitResult blockHit)) { serverPlayer.sendMessage(Text.literal("Aim at a block and confirm again."), false); return TypedActionResult.fail(stack); }
                BlockPos pos = blockHit.getBlockPos().up();
                if (!activate(serverPlayer, type, pos)) return TypedActionResult.fail(stack);
            }
            stack.decrement(1); // consumes even if the item has Mending; Mending cannot restore a consumed wand
            serverPlayer.sendMessage(Text.literal(type.label + " activated."), false);
            return TypedActionResult.success(stack, false);
        });
    }

    private static boolean activate(ServerPlayerEntity player, Wand type, BlockPos pos) {
        long now = System.currentTimeMillis();
        String key = "player:" + player.getUuid(); // scoreboard/army binding is added with the army subsystem
        if (type == Wand.NUKE && !rate(NUKE_USES, key, 3, now)) { player.sendMessage(Text.literal("Nuke limit: 3 per 5 minutes."), false); return false; }
        if (type == Wand.STRIKE && !rate(STRIKE_USES, key, 1, now)) { player.sendMessage(Text.literal("Strike limit: 1 per 5 minutes."), false); return false; }
        if (type != Wand.NUKE && type != Wand.STRIKE && COOLDOWNS.getOrDefault(player.getUuid(), 0L) > now) { player.sendMessage(Text.literal("Orbital cooldown active."), false); return false; }
        ServerWorld world = player.getServerWorld();
        Vec3d center = Vec3d.ofCenter(pos);
        switch (type) {
            case NUKE -> {
                int[] counts = {40, 50, 60, 70, 80, 90, 110, 160};
                double[] radii = {3, 5.5, 8, 11, 14.5, 18.5, 23, 28};
                spawnTnt(world, center.add(0, 50, 0), 72);
                for (int ring = 0; ring < counts.length; ring++) for (int i = 0; i < counts[ring]; i++) {
                    double a = Math.PI * 2 * i / counts[ring] + (ring % 2 == 0 ? 0 : Math.PI / counts[ring]);
                    spawnTnt(world, center.add(Math.cos(a) * radii[ring], 50, Math.sin(a) * radii[ring]), 72);
                }
            }
            case STAB -> {
                int top = Math.min(world.getTopY(Heightmap.Type.WORLD_SURFACE, pos.getX(), pos.getZ()) + 50, pos.getY() + 50);
                int fuse = 80;
                for (int y = top; y > world.getBottomY(); y -= 4) spawnTnt(world, new Vec3d(pos.getX() + .5, y, pos.getZ() + .5), fuse++ / 1);
            }
            case STRIKE -> {
                for (int wave = 0; wave < 10; wave++) for (int i = 0; i < 100; i++) {
                    double a = Math.PI * 2 * i / 100 + wave * .37;
                    Vec3d start = center.add(Math.cos(a) * 26, 10 + i % 7, Math.sin(a) * 26);
                    WitherSkullEntity skull = new WitherSkullEntity(world, player, center.x - start.x, center.y - start.y, center.z - start.z);
                    skull.setPos(start.x, start.y, start.z);
                    skull.setCharged(true);
                    skull.setVelocity(center.subtract(start).normalize().multiply(1.8));
                    world.spawnEntity(skull);
                }
            }
            case WOLF -> {
                for (int i = 0; i < 50; i++) {
                    double a = i * 2.3999632297, r = 1.5 + Math.sqrt(i) * .8;
                    WolfEntity wolf = new WolfEntity(EntityType.WOLF, world);
                    wolf.refreshPositionAndAngles(player.getX() + Math.cos(a) * r, player.getY(), player.getZ() + Math.sin(a) * r, player.getYaw(), 0);
                    wolf.setOwner(player);
                    wolf.setTamed(true);
                    wolf.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 12000, 1));
                    wolf.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 12000, 1));
                    wolf.equipStack(net.minecraft.entity.EquipmentSlot.BODY, new ItemStack(Items.WOLF_ARMOR));
                    world.spawnEntity(wolf);
                }
            }
            case BOSS -> {
                String mode = BOSS_MODE.getOrDefault(player.getUuid(), "WARDEN");
                for (int i = 0; i < 100; i++) {
                    double a = i * 2.3999632297, r = i == 0 ? 0 : 2.5 + Math.ceil(Math.sqrt(i)) * 2.5;
                    Entity boss = mode.equals("WITHER") ? new WitherEntity(EntityType.WITHER, world) : new WardenEntity(EntityType.WARDEN, world);
                    boss.refreshPositionAndAngles(center.x + Math.cos(a) * r, center.y, center.z + Math.sin(a) * r, 0, 0);
                    world.spawnEntity(boss);
                }
            }
            default -> { return false; }
        }
        if (type != Wand.NUKE && type != Wand.STRIKE) COOLDOWNS.put(player.getUuid(), now + 25_000L);
        return true;
    }

    private static boolean useStasis(ServerPlayerEntity player) {
        StasisTarget target = STASIS.get(player.getUuid());
        if (target == null) { player.sendMessage(Text.literal("No Stasis target configured by an OP."), false); return false; }
        MinecraftServer server = player.getServer();
        ServerWorld destination = server.getWorld(net.minecraft.registry.RegistryKey.of(net.minecraft.registry.RegistryKeys.WORLD, net.minecraft.util.Identifier.of(target.worldId)));
        if (destination == null || target.y < destination.getBottomY() + 1 || target.y >= destination.getTopY(Heightmap.Type.WORLD_SURFACE, BlockPos.ofFloored(target.x, target.y, target.z).getX(), BlockPos.ofFloored(target.x, target.y, target.z).getZ()) - 2) { player.sendMessage(Text.literal("Invalid Stasis destination."), false); return false; }
        BlockPos pos = BlockPos.ofFloored(target.x, target.y, target.z);
        if (!destination.getBlockState(pos.down()).isSolidBlock(destination, pos.down()) || !destination.getBlockState(pos).isAir() || !destination.getBlockState(pos.up()).isAir()) {
            player.sendMessage(Text.literal("Stasis destination is not safe (needs solid floor and two air blocks)."), false); return false;
        }
        player.teleport(destination, target.x + .5, target.y, target.z + .5, player.getYaw(), player.getPitch());
        COOLDOWNS.put(player.getUuid(), System.currentTimeMillis() + 25_000L);
        return true;
    }

    private static void spawnTnt(ServerWorld world, Vec3d pos, int fuse) {
        TntEntity tnt = new TntEntity(world, pos.x, pos.y, pos.z, null);
        tnt.setFuse(fuse);
        world.spawnEntity(tnt);
    }

    private static boolean rate(Map<String, Queue<Long>> map, String key, int max, long now) {
        Queue<Long> queue = map.computeIfAbsent(key, k -> new ArrayDeque<>());
        while (!queue.isEmpty() && now - queue.peek() >= FIVE_MIN_MS) queue.poll();
        if (queue.size() >= max) return false;
        queue.add(now);
        return true;
    }

    private static ItemStack makeWand(Wand wand) {
        ItemStack stack = new ItemStack(Items.BLAZE_ROD);
        stack.setCustomName(Text.literal(wand.label));
        return stack;
    }

    private static Wand readWand(ItemStack stack) {
        if (stack.isEmpty() || !stack.isOf(Items.BLAZE_ROD) || !stack.hasCustomName()) return null;
        return Wand.parse(stack.getName().getString());
    }

    private enum Wand {
        NUKE("Nuke"), STAB("Stab"), STRIKE("Strike"), STASIS("Stasis"), WOLF("Wolf"), BOSS("Boss");
        final String label;
        Wand(String label) { this.label = label; }
        static Wand parse(String name) { for (Wand w : values()) if (w.label.equals(name)) return w; return null; }
    }
    private record Pending(Wand type, int slot, long expiresAt) {}
    private record StasisTarget(String worldId, double x, double y, double z) {}
}
